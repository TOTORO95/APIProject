#pragma once
#ifndef __TYPEDEF_H__
class CGameObject;
typedef int Object_type;
typedef int Block_type;
typedef list<CGameObject*> Object_pList;
#define __TYPEDEF_H__
#endif // !__TYPEDEF_H__


