#pragma once
#ifndef __ENUM_H__

enum OBJECT_TYPE
{
	PLAYER,
	BLOCK,
	END_OBJTYPE
};
enum BLOCK_TYPE
{
	RED,
	BLUE,
	YELLOW,
	WHILE,
	END_BLOCK
};
enum OBJECT_STATE
{
	ALLIVE_OBJ,
	DEAD_OBJ
};



#define  __ENUM_H__
#endif // !__ENUM_H__
