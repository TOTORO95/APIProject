#pragma once
#ifndef __STURCT_H__
typedef struct Info
{
	float fPosX, fPosY;
	float fCX, fCY;
}INFO;

typedef struct myColor
{
	int R, G, B;
}MyRGB;


#define __STURCT_H__
#endif // !__STURCT_H__
