#pragma once
#ifndef __DEFINE_H__

#define WinCX 800
#define	WinCY 600
#define PI 3.141592

#define SAFE_DELETE(x) if(x==nullptr) delete x; x=nullptr;


#define  __DEFINE_H__
#endif // !__DEFINE_H__
